"""
Sellvance — Motor de Inteligência de Marketplaces
Análise competitiva, estoque, anúncios, devoluções, saúde da conta
"""

# ── Dados dos concorrentes (simulados com base em dados reais de mercado) ────

COMPETITORS = {
    'mercado_livre': [
        {'id': 'c1', 'name': 'ThermoBox BR',      'rating': 4.7, 'reviews': 2840, 'price_32l': 229.90, 'price_20l': 179.90, 'stock': 'ok',       'sponsored': True,  'badge': 'MercadoLíder Gold',   'shipping': 'grátis', 'fulfillment': True},
        {'id': 'c2', 'name': 'CoolMaster',          'rating': 4.5, 'reviews': 1230, 'price_32l': 199.90, 'price_20l': 159.90, 'stock': 'low',      'sponsored': True,  'badge': 'MercadoLíder',        'shipping': 'grátis', 'fulfillment': False},
        {'id': 'c3', 'name': 'Glacial Coolers',     'rating': 4.3, 'reviews':  890, 'price_32l': 189.90, 'price_20l': 149.90, 'stock': 'ok',       'sponsored': False, 'badge': None,                  'shipping': 'R$15',   'fulfillment': False},
        {'id': 'c4', 'name': 'FrezzPack',           'rating': 3.9, 'reviews':  420, 'price_32l': 169.90, 'price_20l': 129.90, 'stock': 'critical', 'sponsored': False, 'badge': None,                  'shipping': 'R$18',   'fulfillment': False},
        {'id': 'c5', 'name': 'AlpineBox',           'rating': 4.6, 'reviews': 1680, 'price_32l': 249.90, 'price_20l': 199.90, 'stock': 'ok',       'sponsored': True,  'badge': 'MercadoLíder Platinum','shipping': 'grátis','fulfillment': True},
    ],
    'amazon': [
        {'id': 'a1', 'name': 'Coleman Brazil',     'rating': 4.8, 'reviews': 5240, 'price_32l': 259.90, 'price_20l': 199.90, 'stock': 'ok',       'sponsored': True,  'badge': 'Amazon Choice',       'shipping': 'Prime',  'fulfillment': True},
        {'id': 'a2', 'name': 'IceBreaker',          'rating': 4.4, 'reviews':  980, 'price_32l': 209.90, 'price_20l': 169.90, 'stock': 'ok',       'sponsored': True,  'badge': None,                  'shipping': 'Prime',  'fulfillment': True},
        {'id': 'a3', 'name': 'ThermoBox BR',        'rating': 4.6, 'reviews': 1890, 'price_32l': 224.90, 'price_20l': 174.90, 'stock': 'low',      'sponsored': False, 'badge': None,                  'shipping': 'grátis', 'fulfillment': False},
        {'id': 'a4', 'name': 'PolarBox',            'rating': 4.2, 'reviews':  340, 'price_32l': 184.90, 'price_20l': 144.90, 'stock': 'critical', 'sponsored': False, 'badge': None,                  'shipping': 'R$20',   'fulfillment': False},
    ],
    'tiktok_shop': [
        {'id': 't1', 'name': 'IceCool BR',         'rating': 4.6, 'reviews':  820, 'price_32l': 189.90, 'price_20l': 149.90, 'stock': 'ok',       'sponsored': True,  'badge': 'Top Seller',          'shipping': 'grátis', 'fulfillment': False},
        {'id': 't2', 'name': 'FrezBox Oficial',     'rating': 4.3, 'reviews':  340, 'price_32l': 179.90, 'price_20l': 139.90, 'stock': 'low',      'sponsored': True,  'badge': None,                  'shipping': 'grátis', 'fulfillment': False},
        {'id': 't3', 'name': 'CoolVibes',           'rating': 4.1, 'reviews':  180, 'price_32l': 169.90, 'price_20l': 134.90, 'stock': 'ok',       'sponsored': False, 'badge': None,                  'shipping': 'R$12',   'fulfillment': False},
    ],
}

MY_PRODUCTS = {
    'mercado_livre': {'price_32l': 219.90, 'price_20l': 189.90, 'rating': 4.8, 'reviews': 3240, 'stock_32l': 48, 'stock_20l': 9,  'badge': 'MercadoLíder Gold', 'fulfillment': True},
    'amazon':        {'price_32l': 219.90, 'price_20l': 189.90, 'rating': 4.7, 'reviews': 2180, 'stock_32l': 22, 'stock_20l': 0,  'badge': None,                 'fulfillment': False},
    'tiktok_shop':   {'price_32l': 189.90, 'price_20l': 159.90, 'rating': 4.5, 'reviews':  680, 'stock_32l': 67, 'stock_20l': 3,  'badge': 'Top Seller',         'fulfillment': False},
}

MP_ADS_DATA = {
    'mercado_livre': [
        {'name': 'Cooler 32L Azul — Product Ads',  'type': 'product_ads', 'spend': 1240, 'revenue': 8680, 'clicks': 3420, 'impressions': 84000, 'conversions': 89, 'acos': 14.3, 'status': 'active'},
        {'name': 'Cooler 20L — Product Ads',        'type': 'product_ads', 'spend':  680, 'revenue': 2380, 'clicks': 2180, 'impressions': 62000, 'conversions': 25, 'acos': 28.6, 'status': 'active'},
        {'name': 'Kit Cooler — Display Banner',     'type': 'display',     'spend':  420, 'revenue': 1260, 'clicks':  840, 'impressions': 38000, 'conversions': 13, 'acos': 33.3, 'status': 'active'},
        {'name': 'Cooler Verão — Sponsored Brand',  'type': 'sponsored',   'spend':  890, 'revenue': 5340, 'clicks': 2940, 'impressions': 71000, 'conversions': 56, 'acos': 16.7, 'status': 'active'},
    ],
    'amazon': [
        {'name': 'Cooler 32L — Sponsored Products', 'type': 'sponsored',   'spend':  980, 'revenue': 6860, 'clicks': 2840, 'impressions': 68000, 'conversions': 70, 'acos': 14.3, 'status': 'active'},
        {'name': 'Cooler 20L — Sponsored Products', 'type': 'sponsored',   'spend':  340, 'revenue':  680, 'clicks':  980, 'impressions': 31000, 'conversions':  7, 'acos': 50.0, 'status': 'active'},
        {'name': 'Brand Store — Headline Ads',      'type': 'headline',    'spend':  560, 'revenue': 3360, 'clicks': 1680, 'impressions': 45000, 'conversions': 35, 'acos': 16.7, 'status': 'active'},
    ],
    'tiktok_shop': [
        {'name': 'Cooler 32L — Shop Ads',           'type': 'shop_ads',    'spend':  780, 'revenue': 5460, 'clicks': 4200, 'impressions': 98000, 'conversions': 57, 'acos': 14.3, 'status': 'active'},
        {'name': 'Cooler Verão — Video Shopping',   'type': 'video',       'spend':  490, 'revenue': 3430, 'clicks': 2940, 'impressions': 72000, 'conversions': 36, 'acos': 14.3, 'status': 'active'},
        {'name': 'Afiliados — Comissão 8%',         'type': 'affiliate',   'spend':  340, 'revenue': 1020, 'clicks': 1420, 'impressions': 34000, 'conversions': 11, 'acos': 33.3, 'status': 'active'},
    ],
}

RETURNS_DATA = {
    'mercado_livre': {
        'total_orders': 312, 'total_returns': 14, 'return_rate': 4.5,
        'reasons': [
            {'reason': 'Produto diferente do anunciado', 'count': 4, 'pct': 28.6},
            {'reason': 'Defeito de fabricação',          'count': 3, 'pct': 21.4},
            {'reason': 'Arrependimento de compra',       'count': 3, 'pct': 21.4},
            {'reason': 'Chegou danificado',              'count': 2, 'pct': 14.3},
            {'reason': 'Tamanho diferente do esperado',  'count': 2, 'pct': 14.3},
        ],
        'avg_resolution_days': 3.2,
        'refunded_revenue': 2660.40,
        'trend': 'down',  # melhorando
    },
    'amazon': {
        'total_orders': 184, 'total_returns': 12, 'return_rate': 6.5,
        'reasons': [
            {'reason': 'Produto diferente do anunciado', 'count': 5, 'pct': 41.7},
            {'reason': 'Defeito de fabricação',          'count': 3, 'pct': 25.0},
            {'reason': 'Chegou danificado',              'count': 2, 'pct': 16.7},
            {'reason': 'Arrependimento de compra',       'count': 2, 'pct': 16.7},
        ],
        'avg_resolution_days': 4.8,
        'refunded_revenue': 2279.40,
        'trend': 'up',  # piorando
    },
    'tiktok_shop': {
        'total_orders': 241, 'total_returns': 8, 'return_rate': 3.3,
        'reasons': [
            {'reason': 'Arrependimento de compra',       'count': 3, 'pct': 37.5},
            {'reason': 'Produto diferente do anunciado', 'count': 2, 'pct': 25.0},
            {'reason': 'Defeito de fabricação',          'count': 2, 'pct': 25.0},
            {'reason': 'Chegou danificado',              'count': 1, 'pct': 12.5},
        ],
        'avg_resolution_days': 2.1,
        'refunded_revenue': 1519.20,
        'trend': 'stable',
    },
}

ACCOUNT_HEALTH = {
    'mercado_livre': {
        'score': 92, 'level': 'MercadoLíder Gold', 'color': '#f59e0b',
        'metrics': {
            'Reputação': {'val': '98%', 'ok': True},
            'Envio no prazo': {'val': '97%', 'ok': True},
            'Reclamações': {'val': '1.2%', 'ok': True},
            'Cancelamentos': {'val': '0.8%', 'ok': True},
            'Avaliação média': {'val': '4.8 ⭐', 'ok': True},
            'Catálogo ativo': {'val': '6 SKUs', 'ok': True},
        },
        'alerts': [],
    },
    'amazon': {
        'score': 74, 'level': 'Seller Standard', 'color': '#ff9900',
        'metrics': {
            'ODR (Defeito)':   {'val': '2.8%', 'ok': False},
            'Cancelamentos':   {'val': '1.9%', 'ok': False},
            'Envio no prazo':  {'val': '94%',  'ok': True},
            'Avaliação média': {'val': '4.7 ⭐','ok': True},
            'A-to-Z Claims':   {'val': '0.3%', 'ok': True},
            'Fulfillment':     {'val': 'FBM',   'ok': False},
        },
        'alerts': [
            '⚠️ ODR acima de 1% — risco de suspensão da conta',
            '⚠️ Habilitar FBA pode melhorar score e conversão em ~30%',
            '⚠️ Taxa de cancelamento alta — revisar estoque disponível',
        ],
    },
    'tiktok_shop': {
        'score': 88, 'level': 'Top Seller', 'color': '#ff0050',
        'metrics': {
            'Taxa de conclusão': {'val': '96%', 'ok': True},
            'Avaliação média':   {'val': '4.5 ⭐','ok': True},
            'Envio em 48h':      {'val': '91%', 'ok': True},
            'Reclamações':       {'val': '2.1%', 'ok': True},
            'Afiliados ativos':  {'val': '23',   'ok': True},
            'Vídeos ao vivo':    {'val': '0',    'ok': False},
        },
        'alerts': [
            '💡 Lives de vendas podem aumentar conversão em 3-5x no TikTok Shop',
        ],
    },
}


def analyze_competitive_position(marketplace):
    """Analisa posição competitiva e gera recomendações."""
    my   = MY_PRODUCTS.get(marketplace, {})
    comp = COMPETITORS.get(marketplace, [])
    recs = []
    opportunities = []

    my_32l = my.get('price_32l', 0)
    my_20l = my.get('price_20l', 0)

    # Concorrentes com estoque crítico = oportunidade
    critical = [c for c in comp if c['stock'] in ('critical', 'out')]
    if critical:
        names = ', '.join(c['name'] for c in critical)
        opportunities.append({
            'type': 'stock_gap',
            'icon': '📦',
            'title': f"{len(critical)} concorrente(s) com estoque crítico",
            'text': f"{names} — Aumente budget de anúncios agora para capturar demanda",
            'impact': 'Alto',
            'urgency': 'Imediata',
        })

    # Análise de preço
    prices_32l = [c['price_32l'] for c in comp]
    avg_price  = sum(prices_32l) / len(prices_32l) if prices_32l else my_32l
    min_price  = min(prices_32l) if prices_32l else my_32l
    max_price  = max(prices_32l) if prices_32l else my_32l

    if my_32l > avg_price * 1.1:
        recs.append({
            'type': 'price',
            'icon': '💰',
            'title': 'Preço acima da média de mercado',
            'text': f"Seu preço R${my_32l} vs média R${avg_price:.0f}. Considere reduzir ou reforçar percepção de valor com bundle.",
            'priority': 'alta',
        })
    elif my_32l < min_price:
        recs.append({
            'type': 'price',
            'icon': '🏷️',
            'title': 'Você tem o menor preço — oportunidade de margem',
            'text': f"Concorrente mais barato cobra R${min_price}. Você pode subir R${my_32l} até R${min_price - 5:.2f} sem perder competitividade.",
            'priority': 'media',
        })

    # Análise de avaliações
    my_rating   = my.get('rating', 0)
    my_reviews  = my.get('reviews', 0)
    best_rating = max((c['rating'] for c in comp), default=0)
    most_reviews = max((c['reviews'] for c in comp), default=0)

    if my_rating >= best_rating:
        opportunities.append({
            'type': 'rating',
            'icon': '⭐',
            'title': f"Melhor avaliação do marketplace ({my_rating})",
            'text': "Destaque isso no título e imagens — aumenta CTR em até 15%",
            'impact': 'Médio',
            'urgency': 'Esta semana',
        })

    # Concorrentes sem fulfillment = desvantagem deles
    no_fulfillment = [c for c in comp if not c['fulfillment'] and my.get('fulfillment')]
    if no_fulfillment and marketplace == 'mercado_livre':
        opportunities.append({
            'type': 'fulfillment',
            'icon': '🚚',
            'title': f"{len(no_fulfillment)} concorrentes sem Full',",
            'text': "Seu Fulfillment é vantagem competitiva — destaque 'Entrega Full' nos anúncios",
            'impact': 'Alto',
            'urgency': 'Esta semana',
        })

    return {
        'recommendations': recs,
        'opportunities': opportunities,
        'avg_price_32l': round(avg_price, 2),
        'min_price_32l': min_price,
        'max_price_32l': max_price,
        'price_position': 'acima' if my_32l > avg_price else 'abaixo' if my_32l < avg_price * 0.95 else 'alinhado',
    }


def analyze_mp_ads(marketplace):
    """Analisa anúncios internos do marketplace."""
    ads = MP_ADS_DATA.get(marketplace, [])
    results = []
    for ad in ads:
        spend   = ad['spend']
        revenue = ad['revenue']
        clicks  = ad['clicks'] or 1
        impr    = ad['impressions'] or 1
        conv    = ad['conversions'] or 0
        acos    = ad['acos']  # Advertising Cost of Sale %

        roas = round(revenue / spend, 1) if spend > 0 else 0
        ctr  = round(clicks / impr * 100, 2)
        cpc  = round(spend / clicks, 2)
        cpa  = round(spend / conv, 2) if conv > 0 else 0

        # Score do anúncio
        if acos <= 15:
            score = 90; action = 'scale'; label = '🚀 Escalar'
        elif acos <= 25:
            score = 70; action = 'optimize'; label = '⚠️ Otimizar'
        elif acos <= 35:
            score = 50; action = 'watch'; label = '👀 Monitorar'
        else:
            score = 30; action = 'pause'; label = '🔴 Pausar'

        results.append({**ad, 'roas': roas, 'ctr': ctr, 'cpc': cpc, 'cpa': cpa,
                        'score': score, 'action': action, 'action_label': label})
    return sorted(results, key=lambda x: -x['score'])


def get_keyword_opportunities(marketplace):
    """Palavras-chave com alto volume e baixa concorrência."""
    kws = {
        'mercado_livre': [
            {'kw': 'cooler 32 litros',      'volume': 18400, 'competition': 'alta',  'your_pos': 2,  'cpc_est': 1.20, 'opportunity': 'médio'},
            {'kw': 'caixa térmica camping', 'volume': 12800, 'competition': 'média', 'your_pos': 4,  'cpc_est': 0.85, 'opportunity': 'alto'},
            {'kw': 'cooler praia',           'volume': 9200,  'competition': 'média', 'your_pos': 6,  'cpc_est': 0.72, 'opportunity': 'alto'},
            {'kw': 'cooler 20 litros',       'volume': 7600,  'competition': 'baixa', 'your_pos': 8,  'cpc_est': 0.60, 'opportunity': 'muito alto'},
            {'kw': 'caixa de isopor grande', 'volume': 6400,  'competition': 'baixa', 'your_pos': 12, 'cpc_est': 0.45, 'opportunity': 'muito alto'},
            {'kw': 'bolsa térmica 30l',      'volume': 4800,  'competition': 'baixa', 'your_pos': None,'cpc_est': 0.40, 'opportunity': 'muito alto'},
        ],
        'amazon': [
            {'kw': 'cooler box 32l',         'volume': 8400,  'competition': 'alta',  'your_pos': 3,  'cpc_est': 1.40, 'opportunity': 'médio'},
            {'kw': 'caixa termica camping',  'volume': 5600,  'competition': 'média', 'your_pos': 5,  'cpc_est': 0.95, 'opportunity': 'alto'},
            {'kw': 'cooler beach brazil',    'volume': 3200,  'competition': 'baixa', 'your_pos': 9,  'cpc_est': 0.65, 'opportunity': 'muito alto'},
        ],
        'tiktok_shop': [
            {'kw': '#coolerverão',           'volume': 42000, 'competition': 'média', 'your_pos': 4,  'cpc_est': 0.30, 'opportunity': 'muito alto'},
            {'kw': '#caixatermica',          'volume': 28000, 'competition': 'baixa', 'your_pos': 7,  'cpc_est': 0.25, 'opportunity': 'muito alto'},
            {'kw': '#camping',              'volume': 184000, 'competition': 'alta',  'your_pos': None,'cpc_est': 0.50, 'opportunity': 'alto'},
        ],
    }
    return kws.get(marketplace, [])
